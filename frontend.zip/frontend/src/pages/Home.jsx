function Home() {
  return (
    <div className="text-center mt-10">
      <h1 className="text-4xl font-bold text-blue-600">Welcome to SalesSync!</h1>
    </div>
  );
}

export default Home;
